import pycountry
import random
import sys
from termcolor import colored, cprint
countries = []

#Get all the five letter countries from pycountry library
for i in range(len(pycountry.countries)):
  country = list(pycountry.countries)[i]
  if (len(country.name) == 5):
    countries.append(country.name.lower())

#randomly choosing a country and starting the game 
toBeTested = random.choice(countries)
lettersFound = 0
toBeTested = toBeTested.lower()
tested = toBeTested.capitalize()
print("Welcome to country wordle.")
print("You have to figure out the five letter country within five tries\n")
print(colored("Red letter - letter not in country", 'red'))
print(colored("Yellow letter - letter in country but wrong spot", 'yellow'))
print(colored("Green letter - letter in correct spot\n", 'green'))

#Gives five tries to the user to figure out the country
for i in range(5):
  word = str(input("Enter guess: "))
  while(len(word) != 5 or word not in countries) :
    print("Your guess is not valid, try again.")
    word = input("Enter guess: ")
  toBePrinted = ""
  word = word.lower()
  for e in range(5):
    if (word[e] == toBeTested[e]):
      toBePrinted = toBePrinted + colored(word[e], 'green')
    elif (word[e] in toBeTested):
      toBePrinted = toBePrinted + colored(word[e], 'yellow')
    else:
      toBePrinted = toBePrinted + colored(word[e], 'red')
    if(word == toBeTested):
      print("\nYou have found the country!")
      lettersFound = 5
      print(colored(tested, 'green'))
      break
  if (word == toBeTested):
    break
  print(toBePrinted)
if (lettersFound != 5):
  print("\nYou did not find the country. The country was " + tested)